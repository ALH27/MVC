﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace Mvc5LoginSample1.DAL
{
    public class QueryDAL
    {
        public static string conStr = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

        public static Task<DataTable> GetManufactureCode()
        {
            return Task.Run(() =>
            {
                DataTable dt = new DataTable();
                string sql = "Select メーカーコード as ID, メーカー名 as Name from Tメーカーマスタ";
                SqlDataAdapter adpt = new SqlDataAdapter(sql, conStr);
                adpt.Fill(dt);
                return dt;
            });
        }
    }
}
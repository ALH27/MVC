﻿using Mvc5LoginSample1.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace Mvc5LoginSample1.Controllers
{
    public class DataAPIController : ApiController
    {
        [HttpGet]
        [ActionName("GetManufactureCode")]
        public async Task<IHttpActionResult> GetManufactureCode()
        {
            DataTable dt = await QueryDAL.GetManufactureCode();
            return Ok(dt);
        }
    }
}

﻿using Mvc5LoginSample1.DAL;
using Mvc5LoginSample1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace Mvc5LoginSample1.Controllers
{
    public class HatyuController : Controller
    {
        /// <summary> 
        /// 発注一覧
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            var hatyuModelList = new List<HatyuModel>();
            using (var context = new SPEEDDBEntities())
            {
                // DBから発注一覧取得
                //hatyuModelList = context.T_HATYU.AsNoTracking()
                //                .Where(x => x.del_flag == 0)
                //                .Select(x =>
                //                new HatyuModel
                //                {
                //                    Hatyu_Id = x.hatyu_id,
                //                    Maker_Name = x.maker_name,
                //                    Maker_Hinban = x.maker_hinban,
                //                    Shohin_Name = x.shohin_name,
                //                    Hatyusu = (int)x.hatyusu,
                //                    Goda_Zaiko = (int)x.goda_zaiko,
                //                    Maker_Zaiko = (int)x.maker_zaiko,
                //                    Biko = x.biko,
                //                    Renraku = x.renraku,
                //                    Sumicheck = x.sumicheck,
                //                    Kaito = x.kaito,
                //                    ManuCode = x.maker_cd,
                //                }).ToList();

                for (int i = 0; i < 15; i++)
                {
                    HatyuModel model = new HatyuModel();
                    model.Hatyu_Id = i+1;
                    model.Maker_Name = "";
                    model.Maker_Hinban = "";
                    model.Shohin_Name = "";
                    model.Hatyusu = 0;
                    model.Goda_Zaiko = 0;
                    model.Maker_Zaiko = 0;
                    model.Biko = "";
                    model.Renraku = "";
                    model.Sumicheck = "";
                    model.Kaito = "";
                    hatyuModelList.Add(model);
                }

                var fromDatabaseEF = new SelectList(context.Tメーカーマスタ.ToList(), "メーカーコード", "メーカー名");              
                ViewData["DBManuCode"] = fromDatabaseEF;
            }
            return View(hatyuModelList);
        }

        //[HttpPost]
        //public ActionResult Index(List<HatyuModel> model)
        //{
        //    var hatyuModelList = new List<HatyuModel>();
        //    using (SPEEDDBEntities context = new SPEEDDBEntities())
        //    {
        //        foreach(var m in model)
        //        {
        //            T_HATYU hatyu = new T_HATYU();
        //            hatyu.hatyu_date = DateTime.Now;
        //            hatyu.tokisaki_id = HttpContext.User.Identity.Name;
        //            hatyu.tokisaki_name = HttpContext.User.Identity.Name; 
        //            context.SaveChanges();
        //        }
        //    }

        //    return View();
        //}

        [HttpPost]
        public ActionResult Index(HatyuModel model)
        {
            // var hatyuModelList = new List<HatyuModel>();
            using (SPEEDDBEntities context = new SPEEDDBEntities())
            {
                // foreach (var m in model)
                //{
                T_HATYU hatyu = new T_HATYU();
                hatyu.hatyu_date = DateTime.Now;
                hatyu.tokisaki_id = HttpContext.User.Identity.Name;
                hatyu.tokisaki_name = HttpContext.User.Identity.Name;
                context.T_HATYU.Add(hatyu);
                context.SaveChanges();
                // }
            }

            return RedirectToAction("Index","Home");
        }
    }

}
﻿using Mvc5LoginSample1.Models;
using Mvc5LoginSample1.DAL;
using System.Linq;
using System.Web.Mvc;
using System.Web.Security;

namespace Mvc5LoginSample1.Controllers
{
    public class AuthController : Controller
    {
        /// <summary>
        /// ログイン 表示
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult Login()
        {
           // M_USER model = new M_USER();            
            return View();
        }

        /// <summary>
        /// ログイン処理
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Login(AuthModel model)
        {
            bool hasUser = false;
            using (SPEEDDBEntities context = new SPEEDDBEntities())
            {   
                //hasUser = context.M_USER.AsNoTracking().Where(x => x.user_id == model.Id &&
                //                                            x.password == model.Password &&
                //                                            x.del_flag == 0).Any();
                hasUser = context.M_USER.Where(x => x.user_id == model.Id && x.password == model.Password && x.del_flag == 0).Any();
            }
            //if (model.Id == "test" && model.Password == "passwd")
            if (hasUser)
            {
                // ユーザー認証 成功
                FormsAuthentication.SetAuthCookie(model.Id, true);
                return RedirectToAction("Index", "Home");
            }
            else
            {
                // ユーザー認証 失敗
                this.ModelState.AddModelError(string.Empty, "指定されたユーザー名またはパスワードが正しくありません。");
                return this.View(model);
            }
        }

        /// <summary>
        /// ログアウト処理
        /// </summary>
        /// <returns></returns>
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Auth", "Index");
        }
    }
}
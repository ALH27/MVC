﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Mvc5LoginSample1.Models
{
    public class HatyuModel
    {
        public long Hatyu_Id { get; set; }
        [DisplayName("メーカー名")]
        public string Maker_Name { get; set; }

        [DisplayName("品番")]
        [Required(ErrorMessage = "品番は必須入力です。")]
        public string Maker_Hinban { get; set; }

        [DisplayName("商品名")]
        public string Shohin_Name { get; set; }

        [DisplayName("発注数")]
        [Required(ErrorMessage = "発注数は必須入力です。")]
        public int Hatyusu { get; set; }

        [DisplayName("自社在庫")]
        public int Goda_Zaiko { get; set; }

        [DisplayName("メーカー在庫")]
        public int Maker_Zaiko { get; set; }

        [DisplayName("備考")]
        public string Biko { get; set; }

        [DisplayName("連絡")]
        public string Renraku { get; set; }

        [DisplayName("チェック")]
        public string Sumicheck { get; set; }

        [DisplayName("回答")]
        public string Kaito { get; set; }
         public string ManuCode { get; set; }
    }
}